
<link type="text/css" rel="stylesheet" href="leaflet.css">
<?php $scriptList = array('js/jquery3.3.js', './js/leaflet.js', './js/map.js');
include('header.php'); ?>


<main>
    <h3>Hello</h3>
    <p>Please send us a message on facebook.</p>
</main>

<footer><?php include("footer.php"); ?>
</footer>

</body>
</html>