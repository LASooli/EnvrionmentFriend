
<?php

$input = $_POST["ABIinput"];

$output = str_replace('"', '\"', $input);

echo "$output";



    
