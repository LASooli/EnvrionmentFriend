<script type="text/javascript" src="js/GetCart2.js"></script>

