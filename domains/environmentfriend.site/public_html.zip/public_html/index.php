
<?php $scriptList = array('js/jquery3.3.js', 'carousel.js');
     include("header.php"); ?>



        <main>
            <body>
            <h3>
                Welcome to EnvironmentFriend
            </h3>

            <h3>We are a young startup joining the mission of saving the environment</h3>
            </body>

            <div id="carousel"></div>
        </main>

        <footer>
            <?php include("footer.php"); ?>
        </footer>

    </body>
</html>